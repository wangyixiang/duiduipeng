import sendkeys
sendkeys.SendKeys("{LWIN}")